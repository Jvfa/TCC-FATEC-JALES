package br.com.sif.sif;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SifApplication {

	public static void main(String[] args) {
		SpringApplication.run(SifApplication.class, args);
	}

}
