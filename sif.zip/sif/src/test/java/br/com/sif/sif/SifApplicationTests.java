package br.com.sif.sif;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SifApplicationTests {

	@Test
	void contextLoads() {
	}

}
